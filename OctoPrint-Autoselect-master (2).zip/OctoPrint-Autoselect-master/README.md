---

# OctoPrint-Autoselect

The Autoselect Plugin will automatically select newly uploaded files for
printing if there is an active connection to a printer and currently no print
job running.

## Setup

Install via the bundled [Plugin Manager](https://github.com/foosel/OctoPrint/wiki/Plugin:-Plugin-Manager)
or manually using this URL:

    https://github.com/OctoPrint/OctoPrint-Autoselect/archive/master.zip
